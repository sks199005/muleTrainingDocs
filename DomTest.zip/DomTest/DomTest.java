package com.company.camel.file;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DomTest {

public static void main(String[] args) {
		
		try {
			File fXmlFile = new File("D:/soap_request.xml");
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			
			/*DocumentBuilderFactory documentBuilderFactory = 
				    DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();

			Element rootElement = document.createElement("xsl:stylesheet");*/

			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			StringBuilder sb = new StringBuilder();
			if (doc.hasChildNodes()) {
				
				printNote(doc.getChildNodes(), sb);
				
			} 
			//System.out.println("XML "+sb);
			/*doc.appendChild(doc.getDocumentElement()); 
			Element em = document.createElement("xsl:template");
			em.setAttribute("match", "/");
			document.appendChild(em);
			Element templateElement = document.createElement("xsl:apply-templates");
			em.appendChild(templateElement);
			//document.appendChild(em);
			System.out.println("XSL "+document.toString());*/
		} catch (Exception e) {
		  System.out.println(e.getMessage());
		}
	}
			
	private static void printNote(NodeList nodeList, StringBuilder sb) {
		
		for (int count = 0; count < nodeList.getLength(); count++) {
			Node tempNode = nodeList.item(count);
			
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {
				// get node name and value
				//System.out.println("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
				
				if (tempNode.getNodeName().contains("SOAP-ENV")) {
					String soap = sb.toString();
					
					if (soap.contains("SOAP-ENV:Envelope") && soap.contains("SOAP-ENV:Header") && soap.contains("<SOAP-ENV:Body>")) {
						if (soap.contains("</SOAP-ENV:Envelope>")) {
							System.out.println("END HERE");
						} else {
						sb = new StringBuilder();
						//sb.append(tempNode.getNodeName());
						}
					}
					
				}
				
				if (!tempNode.getNodeName().contains("SOAP-ENV") && !tempNode.getNodeName().contains("Request")) {
					String cdata = sb.toString();
					if (!cdata.contains("<![CDATA[")) {
						sb.append("<![CDATA[");
					}
					
				}
				sb.append("<").append(tempNode.getNodeName());
				//System.out.println("Node Value =" + tempNode.getTextContent());
				
				if (tempNode.hasAttributes()) {
					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();
					
					for (int i = 0; i < nodeMap.getLength(); i++) {
						Node node = nodeMap.item(i);
						//System.out.println("attr name : " + node.getNodeName());
						sb.append(" ").append(node.getNodeName());
						//System.out.println("attr value : " + node.getNodeValue());
						sb.append("=").append("\"").append(node.getNodeValue()).append("\"");
					}
				}
				if (!tempNode.getNodeName().equals("SOAP-ENV:Header")) {
					sb.append(">");
				}
				
				if (tempNode.hasChildNodes()) {
					printNote(tempNode.getChildNodes(), sb);
				}
				
				/*String soap = sb.toString();
				if (soap.contains("</SOAP-ENV:Body>") && soap.contains("</SOAP-ENV:Envelope>") && tempNode.getNodeName().equals("SOAP-ENV:Envelope")) {
					break;
				}*/
				if (!tempNode.getNodeName().contains("SOAP-ENV") && !tempNode.getNodeName().contains("Request")) {
					
					sb.append(tempNode.getTextContent());
				}
				if (tempNode.getNodeName().contains("Request")) {
					sb.append("]]>");
				}
				
				if (tempNode.getTextContent() != null && !tempNode.getTextContent().equals("")) {
					sb.append("</").append(tempNode.getNodeName()).append(">");
					
					
				} else {
					sb.append(" />");
				}
				String soap = sb.toString();
				System.out.println(soap);
				//System.out.println("Node Name =" + tempNode.getNodeName() + " [CLOSE]");
				
			}
			
			
		}
		
	}

}
