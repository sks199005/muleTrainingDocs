package com.company.camel.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class FileReadWriteProcessor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		File file = exchange.getIn().getBody(File.class);
		BufferedReader br =null;
		String str;
		StringBuilder sb = new StringBuilder();
		try {
			br = new BufferedReader(new FileReader(file));
			System.out.println("Outside");
			while ((str = br.readLine()) != null) {
				if (str.startsWith("Develop")) {
					System.out.println("Inside");
					sb.append(str);
				}
				
			}
			exchange.getIn().setBody(sb);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
