package com.company.camel.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class FileReadWriteProcessor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    Document doc = factory.newDocumentBuilder().parse("D:/soap_request.xml");

	    addCDATA(doc);

	    //System.out.println(documentToString(doc));
	    exchange.getIn().setBody(documentToString(doc));
	}
	
	public static void addCDATA(Document doc) {
	    Element root = doc.getDocumentElement();
	    Element first = (Element) root.getFirstChild();
	    System.out.println("First Child "+first);
	    Element next = (Element) first.getNextSibling();
	    System.out.println("Next Child "+next);
	    Element last = (Element) next.getLastChild();
	    System.out.println("Last Child "+last);
	    String text = last.getTextContent();
	    System.out.println("Actual Text "+text);
	    String dirtext = text;
	    CDATASection dirdata = doc.createCDATASection(dirtext);
	    last.replaceChild(dirdata, last.getFirstChild());
	  }
	
	public static String documentToString(Document document) {
	    try {
	      TransformerFactory tf = TransformerFactory.newInstance();
	      Transformer trans = tf.newTransformer();
	      StringWriter sw = new StringWriter();
	      trans.transform(new DOMSource(document), new StreamResult(sw));
	      return sw.toString();
	    } catch (TransformerException tEx) {
	      tEx.printStackTrace();
	    }
	    return null;
	  }
}
